import threading, webbrowser, time
import sys, collections
# --- Terminal-Buffer (max. 20 Zeilen sichtbar) ---
class LimitedBuffer:
    def __init__(self, max_lines=20):
        self.lines = collections.deque(maxlen=max_lines)
    def write(self, text):
        if isinstance(text, bytes):
            text = text.decode(errors='ignore')
        if text.strip():
            self.lines.append(text)
            sys.__stdout__.write(text)
    def flush(self):
        sys.__stdout__.flush()
sys.stdout = LimitedBuffer(max_lines=20)

import dash_bootstrap_components as dbc
from dash import Dash, html, dash_table, dcc
from dash.dependencies import Input, Output
import pandas as pd

from core.shared_state import shared_state
from core.ws_client.spot_ws import run as run_spot_ws
from core.ws_client.futures_ws import run as run_futures_ws
from core.scanner import start_scanner_thread, start_auto_trade

SCAN_INTERVAL = 30

def reset_dashboard_state():
    # Nur UI/Daycap; Lernen bleibt unberührt
    with shared_state.lock:
        shared_state.open_trades.clear()
        shared_state.closed_trades.clear()
        shared_state.accounts.setdefault("daycap", {"total":175.0,"used":0.0,"scalper_cap":70.0,"scalper_used":0.0})
        shared_state.accounts["daycap"].update({"total":175.0,"used":0.0,"scalper_cap":70.0,"scalper_used":0.0})
        shared_state.accounts.setdefault("hot_coins", [])
        shared_state.accounts.setdefault("last_scan_ts", 0.0)
        shared_state.accounts.setdefault("trade_stats", {})
        shared_state.accounts.setdefault("last_trade", {})
        shared_state.accounts.setdefault("total_pnl", 0.0)
        shared_state.ws_status.update({"spot":"disconnected","futures":"disconnected"})
        shared_state.autosave()

def boot_all():
    reset_dashboard_state()
    print("[BOOT] Starte Systeme...")
    threading.Thread(target=run_spot_ws,     daemon=True, name="SpotWS").start()
    threading.Thread(target=run_futures_ws,  daemon=True, name="FuturesWS").start()
    time.sleep(1)
    start_scanner_thread()
    start_auto_trade()
    print("[BOOT] Alle Systeme aktiviert ✅")

# ---------------- Dashboard ----------------
app = Dash(__name__, external_stylesheets=[dbc.themes.DARKLY])

def _table(df: pd.DataFrame, table_id: str, page_size=8):
    if df is None or df.empty:
        cols = [{"name":"—","id":"—"}]; data=[]
    else:
        cols = [{"name":c,"id":c} for c in df.columns]
        data = df.to_dict("records")
    return dash_table.DataTable(
        id=table_id, data=data, columns=cols, page_size=page_size,
        style_table={"overflowX":"auto"},
        style_cell={"textAlign":"center","backgroundColor":"#1e1e1e","color":"#FFFFFF","fontSize":"12px","padding":"6px"},
        style_header={"backgroundColor":"#111","fontWeight":"700"}
    )

def make_layout():
    return dbc.Container([
        # Kopfzeile
        dbc.Row([
            dbc.Col(html.H2("Trading-BotDashBot",
                            style={"fontWeight":"800","letterSpacing":"0.5px"}),
                    width=7),
            dbc.Col(dbc.Card([
                dbc.CardHeader("₿ BTC Live"),
                dbc.CardBody(html.H4(id="btc_price", className="text-end mb-0"))
            ], style={"minHeight":"70px"}), width=2),
            dbc.Col(dbc.Card([
                dbc.CardHeader("💹 Total PnL"),
                dbc.CardBody(html.H4(id="total_pnl", className="text-end mb-0"))
            ], style={"minHeight":"70px"}), width=3),
        ], className="mt-3 mb-2", align="center"),

        # Statuskarten
        dbc.Row([
            dbc.Col(dbc.Card([
                dbc.CardHeader("⏱️ Scan-Timer"),
                dbc.CardBody(html.H5(id="timer_display", className="text-center mb-0", style={"fontSize":"14px"}))
            ]), width=3),
            dbc.Col(dbc.Card([
                dbc.CardHeader("💰 Daycap"),
                dbc.CardBody(html.Div(id="daycap_display", className="text-center mb-0", style={"fontSize":"14px"}))
            ]), width=4),
            dbc.Col(dbc.Card([
                dbc.CardHeader("🔌 WSS Status"),
                dbc.CardBody(html.Div(id="wss_status", className="text-center mb-0", style={"fontSize":"14px"}))
            ]), width=5),
        ], className="mb-3"),

        # Top10 + Diagnose
        dbc.Row([
            dbc.Col(dbc.Card([
                dbc.CardHeader("🔥 Top 10 Coins"),
                dbc.CardBody(html.Div(id="top10_wrap"))
            ]), width=6),
            dbc.Col(dbc.Card([
                dbc.CardHeader("🧪 Diagnose – Letzter Trade"),
                dbc.CardBody(html.Div(id="last_trade_box", style={"fontSize":"13px"})),
                dbc.CardHeader("📈 Diagnose – Trades pro Symbol"),
                dbc.CardBody(html.Div(id="trade_stats_wrap"))
            ]), width=6)
        ], className="mb-3"),

        # Trades
        dbc.Card([
            dbc.CardHeader("📊 Offene Trades"),
            dbc.CardBody(html.Div(id="open_wrap"))
        ], className="mb-3"),

        dbc.Card([
            dbc.CardHeader("📈 Geschlossene Trades"),
            dbc.CardBody(html.Div(id="closed_wrap"))
        ]),

        dcc.Interval(id="refresh", interval=1000, n_intervals=0)
    ], fluid=True)

app.layout = make_layout()

@app.callback(
    [   # Header + Status
        Output("btc_price","children"),
        Output("total_pnl","children"),
        Output("timer_display","children"),
        Output("daycap_display","children"),
        Output("wss_status","children"),
        # Tabellen/Boxen (als HTML-Container)
        Output("top10_wrap","children"),
        Output("trade_stats_wrap","children"),
        Output("last_trade_box","children"),
        Output("open_wrap","children"),
        Output("closed_wrap","children")
    ],
    Input("refresh","n_intervals"))
def update(_):
    with shared_state.lock:
        dc = shared_state.accounts.get("daycap", {})
        last_scan = shared_state.accounts.get("last_scan_ts", 0.0)
        hot = shared_state.accounts.get("hot_coins", [])
        trade_stats = shared_state.accounts.get("trade_stats", {})
        last_trade = shared_state.accounts.get("last_trade", {})
        total_pnl = float(shared_state.accounts.get("total_pnl", 0.0))
        ws = dict(shared_state.ws_status)
        ticks = dict(shared_state.ticks)
        open_t = list(shared_state.open_trades)
        closed_t = list(shared_state.closed_trades)

    # BTC live (Spot)
    btc_px = ticks.get(("spot","BTCUSDT"),{}).get("price")
    btc_txt = f"{btc_px:.2f}" if isinstance(btc_px,(int,float)) else "–"

    # Total PnL
    total_pnl_txt = f"{total_pnl:+.2f} USDT"

    # Timer
    remain = max(0, SCAN_INTERVAL - int(time.time() - last_scan))
    timer = f"Nächster Scan in {remain}s"

    # Daycap
    used = float(dc.get("used", 0.0))
    total = float(dc.get("total", 175.0))
    scal_used = float(dc.get("scalper_used", 0.0))
    scal_cap  = float(dc.get("scalper_cap", 70.0))
    daycap = f"{used:.2f}/{total:.2f} USDT • Scalper {scal_used:.2f}/{scal_cap:.2f}"

    # WSS
    wss_txt = f"Spot: {ws.get('spot','?')} • Futures: {ws.get('futures','?')}"

    # Tabellen bauen
    top10_df = pd.DataFrame({"Symbol": hot})
    stats_df = pd.DataFrame(sorted(trade_stats.items(), key=lambda x: (-x[1], x[0])), columns=["Symbol","Trades"])
    open_df = pd.DataFrame(open_t)
    closed_df = pd.DataFrame(closed_t)

    top10_table = _table(top10_df, "top10_table", page_size=10)
    stats_table = _table(stats_df, "trade_stats_table", page_size=8)
    open_table  = _table(open_df,  "open_table",  page_size=8)
    closed_table= _table(closed_df,"closed_table",page_size=8)

    # Letzter Trade Box
    if last_trade:
        lt = last_trade
        last_box = f"{lt['symbol']} • {lt['decision'].upper()} • @ {lt['price']:.4f} • Quelle: {lt.get('source','?')}"
    else:
        last_box = "—"

    return (btc_txt, total_pnl_txt, timer, daycap, wss_txt,
            top10_table, stats_table, last_box, open_table, closed_table)

if __name__=="__main__":
    boot_all()
    url = "http://127.0.0.1:8050/"
    try:
        webbrowser.open(url)
        print("[BOOT] Dashboard im Browser geöffnet ✅")
    except Exception as e:
        print(f"[BOOT] Browser-Open fehlgeschlagen ({e}). Bitte manuell öffnen: {url}")
    

try:
    from core.ai import online_rl
    print("[BOOT] Zusätzlicher Lern/Status-Hook aktiv ✅")
    online_rl.start_online_rl_thread_with_meta()
    print("[ONLINE_RL] Live-Training gestartet ✅")
except Exception as e:
    print("[BOOT] Lernsystem konnte nicht gestartet werden:", e)


def start_learning_hook():
    try:
        from core.ai import online_rl
        print('[BOOT] Zusätzlicher Lern/Status-Hook aktiv ✅')
        t = online_rl.start_online_rl_thread_with_meta()
        print('[ONLINE_RL] Live-Training gestartet ✅ (Thread)')
        return t
    except Exception as e:
        print('[BOOT] Lernsystem konnte nicht gestartet werden:', e)
        return None

import threading
_t = threading.Thread(target=start_learning_hook, daemon=True)
_t.start()

  # <- behält  Zeile

if __name__ == "__main__":
    print("[BOOT] Starte Systeme...")
    from core.ai import online_rl
    import threading, time, webbrowser

    try:
        from core.ai import learning_module
    except Exception as e:
        print("[BOOT] Warnung: learning_module nicht gefunden:", e)

    # Starte Lernsystem
    try:
        print("[BOOT] Lernsystem aktivieren…")
        threading.Thread(target=online_rl.start_online_rl_thread_with_meta, daemon=True).start()
        print("[ONLINE_RL] Live-Training gestartet ✅")
    except Exception as e:
        print("[BOOT] Lernsystem konnte nicht gestartet werden:", e)

    # Dashboard starten
    try:
        print("[BOOT] Dashboard wird gestartet…")
        url = "http://127.0.0.1:8050/"
        threading.Thread(target=lambda: (time.sleep(3), webbrowser.open(url)), daemon=True).start()
        app.run(host="0.0.0.0", port=8050, debug=False, use_reloader=False)
    except Exception as e:
        print("[BOOT] Dashboard konnte nicht gestartet werden:", e)
