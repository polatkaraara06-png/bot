import time, random
from ..shared_state import shared_state
from core.ai import online_rl

# -------- Helpers --------
def _as_float(x, default=None):
    try:
        if isinstance(x, (int, float)): return float(x)
        if isinstance(x, str): return float(x.strip())
    except Exception:
        return default
    return default

def _extract_prices_from_ticks():
    prices = []
    with shared_state.lock:
        for v in shared_state.ticks.values():
            if isinstance(v, dict) and "price" in v:
                p = _as_float(v["price"])
                if p is not None and p > 0:
                    prices.append(p)
    return prices

def _current_price_for(symbol, market="spot", fallback=None):
    with shared_state.lock:
        v = shared_state.ticks.get((market, symbol), {})
    if isinstance(v, dict) and "price" in v:
        p = _as_float(v["price"])
        return p if (p is not None and p > 0) else fallback
    return fallback

def _dynamic_leverage():
    prices = _extract_prices_from_ticks()
    if len(prices) >= 2:
        hi, lo = max(prices), min(prices)
        vola = (hi - lo) / hi if hi > 0 else 0.0
    else:
        vola = 0.0
    if vola < 0.002: return 2.0
    if vola < 0.005: return 3.0
    if vola < 0.01:  return 4.0
    return 5.0

def _snapshot_features(symbol, side, entry, exit_p, qty, lev):
    # sehr kleine, robuste Marktsignale (damit nichts crasht)
    prices = _extract_prices_from_ticks()
    if len(prices) >= 3:
        last = prices[-1]
        prev = prices[-2]
        prev2= prices[-3]
        r1 = (last - prev) / prev if prev else 0.0
        r2 = (prev - prev2) / prev2 if prev2 else 0.0
    else:
        r1 = r2 = 0.0
    feat = {
        "side": side,
        "lev": float(lev),
        "ret1": float(r1),
        "ret2": float(r2),
        "entry": float(entry),
        "exit": float(exit_p),
        "qty": float(qty),
    }
    return feat

def _send_reward_to_rl(symbol, side, pnl, entry, exit_p, qty, lev):
    try:
        if pnl != 0:
            action = f"close_{side}"
            reward = float(pnl)
            features = _snapshot_features(symbol, side, entry, exit_p, qty, lev)
            online_rl.add_experience(symbol, action, reward, features)
            print(f"[RL] Reward → {symbol}: {reward:+.2f}")
    except Exception as e:
        print("[RL] ⚠️ Reward-Fehler:", e)

# -------- Hauptfunktion --------
def execute_trade(symbol, action, price):
    '''
    Paper-Trading mit Long/Short, dynamischem Hebel (2x-5x),
    Daycap-Management und RL-Reward. RAM-schonend:
    - nur 5 geschlossene Trades behalten
    - offene Trades auf max. 5 begrenzen
    - realisierter PnL aus geschlossenen Trades
    '''
    now = time.time()
    price = _as_float(price, 0.0)
    if not price or price <= 0:
        return
    with shared_state.lock:
        daycap = shared_state.accounts.setdefault("daycap", {"total": 175.0, "used": 0.0})
        total_cap = float(daycap.get("total", 175.0))
        used_cap  = float(daycap.get("used",  0.0))
        open_trades    = shared_state.open_trades
        closed_trades  = shared_state.closed_trades

        lev = _dynamic_leverage()
        trade_value = random.uniform(10, 25)
        # Daycap prüfen
        if (used_cap + trade_value) > total_cap:
            print(f"[PAPER] ⚠️ Daycap erschöpft ({used_cap:.2f}/{total_cap:.2f})")
            return

        qty = trade_value / max(price, 1e-9)
        # Position eröffnen
        if action == "buy":
            open_trades.append({
                "symbol": symbol, "side": "long", "entry_price": float(price),
                "qty": float(qty), "timestamp": now, "leverage": float(lev)
            })
            daycap["used"] = float(used_cap + trade_value)
            print(f"[PAPER] LONG  {symbol} @ {price:.4f} | {trade_value:.2f} USDT (x{lev:.1f})")
        elif action == "sell":
            open_trades.append({
                "symbol": symbol, "side": "short", "entry_price": float(price),
                "qty": float(qty), "timestamp": now, "leverage": float(lev)
            })
            daycap["used"] = float(used_cap + trade_value)
            print(f"[PAPER] SHORT {symbol} @ {price:.4f} | {trade_value:.2f} USDT (x{lev:.1f})")

        # RAM-Schutz: offene Trades auf 5 begrenzen (älteste zuerst raus)
        if len(open_trades) > 5:
            del open_trades[:-5]

        # Auto-Close nach ~5s (Demo-Simulation)
        now2 = time.time()
        to_close = [pos for pos in list(open_trades) if (now2 - float(pos.get("timestamp", now2))) > 5.0]
        for pos in to_close:
            cur   = _current_price_for(pos["symbol"], "spot", fallback=pos["entry_price"])
            entry = float(pos["entry_price"])
            qty2  = float(pos["qty"])
            levp  = float(pos.get("leverage", 1.0))
            if pos["side"] == "long":
                pnl = (cur - entry) * qty2 * levp
            else:
                pnl = (entry - cur) * qty2 * levp

            closed_trades.append({
                "symbol": pos["symbol"], "side": pos["side"],
                "entry_price": entry, "exit_price": float(cur),
                "qty": qty2, "leverage": levp, "pnl": float(pnl), "timestamp": now2
            })
            # Nur die letzten 5 geschlossenen Trades behalten
            if len(closed_trades) > 5:
                del closed_trades[:-5]
            # Position aus open_trades entfernen
            try:
                open_trades.remove(pos)
            except ValueError:
                pass
            # Daycap used anpassen (Eintrittswert - ggf. Gewinnanteil)
            entry_val = entry * qty2
            used_cap2 = float(daycap.get("used", 0.0))
            
if pnl >= 0:
    # Adaptive-Regeneration bei Gewinn: Daycap leicht erhöhen (max 175)
    freed = entry_val * 0.9 + pnl * 0.6
    daycap["used"] = float(max(0.0, used_cap2 - freed))
    daycap["total"] = min(175.0, float(daycap.get("total", 175.0)) + pnl * 0.05)
else:
    # Bei Verlust: leicht verringern, aber nie unter 50 USDT
    freed = entry_val * 0.9
    daycap["used"] = float(max(0.0, used_cap2 - freed))
    daycap["total"] = max(50.0, float(daycap.get("total", 175.0)) - abs(pnl) * 0.02)
