import threading, time, os, json, pickle
from collections import defaultdict, deque

EXPERIENCE_LOG = "data/experience.jsonl"
MODEL_PATH = "models/rl_model.pkl"

buffer_lock = threading.Lock()
experience_buffer = []          # list of dicts
train_queue = deque()           # items taken from buffer for training
model = {
    "symbol_avg": {},           # symbol -> {"n":int, "mean":float}
    "action_avg": {},           # (symbol,action) -> {"n":int, "mean":float}
    "updated_ts": 0.0
}

def _safe_mkdirs():
    os.makedirs("data", exist_ok=True)
    os.makedirs("models", exist_ok=True)

def _append_jsonl(path, obj):
    _safe_mkdirs()
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")

def _tail_jsonl(path, max_lines=1000):
    if not os.path.exists(path): return []
    lines = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                lines.append(line)
    if len(lines) > max_lines:
        lines = lines[-max_lines:]
    out = []
    for ln in lines:
        try:
            out.append(json.loads(ln))
        except Exception:
            pass
    return out

def _save_model():
    _safe_mkdirs()
    with open(MODEL_PATH, "wb") as f:
        pickle.dump(model, f)

def _load_model():
    if os.path.exists(MODEL_PATH):
        try:
            with open(MODEL_PATH, "rb") as f:
                m = pickle.load(f)
            if isinstance(m, dict):
                model.update(m)
        except Exception:
            pass

# public API
def add_experience(symbol, action, reward, next_state=None):
    """Persistente Experience-Logik + RAM-Buffer."""
    exp = {
        "ts": time.time(),
        "symbol": symbol,
        "action": action,
        "reward": float(reward) if isinstance(reward,(int,float)) else 0.0,
        "features": next_state or {}
    }
    with buffer_lock:
        experience_buffer.append(exp)
        if len(experience_buffer) > 5000:
            del experience_buffer[:len(experience_buffer)-5000]
        # sofort persistent sichern
        try:
            _append_jsonl(EXPERIENCE_LOG, exp)
        except Exception:
            pass
    print(f"[ONLINE_RL] +Experience ({symbol}, {action}, {exp['reward']:+.2f})")

def _train_step(exp):
    # sehr einfache "Policy": gleitender Reward-Durchschnitt
    sym = exp.get("symbol")
    act = exp.get("action")
    r   = float(exp.get("reward", 0.0))
    # pro Symbol
    srec = model["symbol_avg"].setdefault(sym, {"n":0, "mean":0.0})
    srec["n"] += 1
    srec["mean"] += (r - srec["mean"]) / srec["n"]
    # pro (Symbol,Action)
    arec = model["action_avg"].setdefault((sym,act), {"n":0, "mean":0.0})
    arec["n"] += 1
    arec["mean"] += (r - arec["mean"]) / arec["n"]
    model["updated_ts"] = time.time()

def learning_loop_meta():
    print("[ONLINE_RL] Live-Learning Loop aktiv ✅")
    _safe_mkdirs()
    _load_model()
    # alte Experiences (Tail) vorm Start in RAM holen
    tail = _tail_jsonl(EXPERIENCE_LOG, max_lines=1000)
    with buffer_lock:
        for exp in tail:
            experience_buffer.append(exp)
    # Hauptloop
    last_save = time.time()
    while True:
        # RAM->Trainqueue
        with buffer_lock:
            while experience_buffer:
                train_queue.append(experience_buffer.pop(0))
        # Train
        processed = 0
        while train_queue:
            exp = train_queue.popleft()
            _train_step(exp)
            processed += 1
        # sporadisch sichern
        now = time.time()
        if processed > 0 or (now - last_save) > 30:
            try:
                _save_model()
            except Exception:
                pass
            last_save = now
        time.sleep(1.5)

def start_online_rl_thread_with_meta():
    t = threading.Thread(target=learning_loop_meta, daemon=True, name="OnlineRL")
    t.start()
    print("[ONLINE_RL] Live-Training gestartet ✅")
    return t

def start_online_rl_thread():
    return start_online_rl_thread_with_meta()