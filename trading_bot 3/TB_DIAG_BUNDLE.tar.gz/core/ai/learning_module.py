import os, threading, time, pickle
import numpy as np

MODEL_PATH = "models/ai_supervised.pkl"
EXPERIENCE_FILE = "models/experience_buffer.npy"

experience_buffer = []

def add_experience(exp):
    """Neue Erfahrung zum Speicher hinzufügen"""
    experience_buffer.append(exp)
    if len(experience_buffer) > 1000:
        experience_buffer.pop(0)
    print(f"[LEARN] Neue Experience gespeichert → mem={len(experience_buffer)}")

def save_model(q_table):
    """Speichere das Lernmodell"""
    os.makedirs("models", exist_ok=True)
    with open(MODEL_PATH, "wb") as f:
        pickle.dump(q_table, f)
    print("[LEARN] Model gespeichert ✅")

def load_model():
    """Lade gespeichertes Modell"""
    if os.path.exists(MODEL_PATH):
        with open(MODEL_PATH, "rb") as f:
            q_table = pickle.load(f)
        print(f"[LEARN] Modell geladen ({len(q_table)} Einträge) ✅")
        return q_table
    else:
        print("[LEARN] Kein gespeichertes Modell gefunden – starte neu.")
        return {}

def learning_loop():
    """Offline-Lernprozess"""
    print("[LEARN] Lernloop aktiv – wartet auf Erfahrungen...")
    q_table = load_model()
    while True:
        if len(experience_buffer) >= 10:
            batch = experience_buffer[-10:]
            for state, action, reward, next_state in batch:
                q_table[state] = reward  # vereinfachtes Beispiel
            save_model(q_table)
            print(f"[LEARN] Offline update ✓  mem={len(experience_buffer)} batch={len(batch)}")
        time.sleep(15)

def start_learning_thread():
    """Startet den Lernthread"""
    print("[LEARN] Lernsystem gestartet ✅")
    t = threading.Thread(target=learning_loop, daemon=True)
    t.start()
