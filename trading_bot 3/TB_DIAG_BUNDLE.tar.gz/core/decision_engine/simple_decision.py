"""
Simple Decision (robust):
- Holt Preis ausschließlich als Float aus shared_state.ticks[("spot", symbol")]
- Mini-Momentum (deterministisch, ohne Zufall)
- Gibt "buy"/"sell" zurück – niemals dict-Vergleiche
"""
from ..shared_state import shared_state

def _to_float(x):
    try:
        if isinstance(x, (int, float)): return float(x)
        if isinstance(x, str): return float(x.strip())
    except Exception:
        return None
    return None

def _deep_price(v):
    if v is None: return None
    if isinstance(v, (int, float, str)): return _to_float(v)
    if isinstance(v, dict):
        for k in ("price","lastPrice","markPrice","p","value","data"):
            if k in v:
                p = _deep_price(v[k])
                if p is not None: return p
    if isinstance(v, list):
        for it in v:
            p = _deep_price(it)
            if p is not None: return p
    return None

def _get_price(symbol, market="spot"):
    with shared_state.lock:
        tick = shared_state.ticks.get((market, symbol))
    return _deep_price(tick)

def make_decision(symbol: str) -> str:
    # Mini-Momentum über 5er-Buffer
    p = _get_price(symbol)
    if p is None:
        return "sell"
    with shared_state.lock:
        sig = shared_state.accounts.setdefault("signal_buf", {})
        buf = sig.setdefault(symbol, [])
        buf.append(float(p))
        if len(buf) > 5:
            buf.pop(0)
        sig[symbol] = buf
    if len(buf) < 2:
        return "sell"
    prev, last = buf[-2], buf[-1]
    if prev is None or prev <= 0:
        return "sell"
    delta = last - prev
    if abs(delta)/prev < 1e-4:  # 0.01% Toleranz
        return "sell"
    return "buy" if delta > 0 else "sell"
