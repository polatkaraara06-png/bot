
import os, json
from flask import Flask
import dash
from dash import html, dcc, dash_table
from dash.dependencies import Input, Output
import pandas as pd
from core.shared_state import shared_state

# -------- App --------
server = Flask(__name__)
# Version-Tag zwingt den Client zum Neuladen, wenn sich die Layout-Struktur ändert
APP_VERSION = "neo-compact-v2"
app = dash.Dash(__name__, server=server, title="CrazyBot Dashboard")

REFRESH_MS = 1000

# -------- Farben / Style --------
BG   = "#141414"
CARD = "#1f2023"
BORD = "#2c2d31"
TXT  = "#e8e8ea"
ACC  = "#05f0ff"   # neonblau Akzent
POS  = "#00e08a"
NEG  = "#ff4d7d"

card_style = {
    "backgroundColor": CARD,
    "border": f"1px solid {BORD}",
    "borderRadius": "10px",
    "padding": "12px",
    "margin": "8px",
    "boxShadow": "0 0 18px rgba(5,240,255,0.08)"
}

tbl_cell = {"backgroundColor": CARD, "color": TXT, "textAlign": "center", "fontSize":"13px", "padding":"6px"}
tbl_head = {"backgroundColor": "#25262a", "color": ACC, "fontWeight": "700", "borderBottom": f"1px solid {BORD}"}

def kpi(title, id_):
    return html.Div([
        html.Div(title, style={"fontSize":"12px","letterSpacing":"0.6px","color":ACC,"opacity":"0.9"}),
        html.Div(id=id_, style={"fontSize":"22px","fontWeight":"800","color":TXT, "marginTop":"2px"})
    ], style=card_style)

def section(title, children):
    return html.Div([
        html.Div(title, style={"color":ACC,"fontWeight":"800","marginBottom":"6px"}),
        children
    ], style=card_style)

app.layout = html.Div([
    # Version-Hint (zwingt Frontend-Refresh bei ID-Änderungen)
    html.Div(APP_VERSION, id="__version__", style={"display":"none"}),

    html.Div("CrazyBot Dashboard", style={
        "color":ACC, "textAlign":"center","fontWeight":"900","fontSize":"26px","margin":"10px 0" }),
    html.Div(id="status", style={"color":TXT,"textAlign":"center","marginBottom":"8px","opacity":"0.9"}),

    html.Div([
        kpi("BTC/USDT", "btc_live"),
        kpi("Daycap (used / total)", "daycap_box"),
        kpi("Total PnL", "pnl_box"),
    ], style={"display":"grid","gridTemplateColumns":"repeat(3, 1fr)","gap":"8px"}),

    html.Div([
        section("📈 Trades (Open)", dash_table.DataTable(
            id="tbl_open",
            page_size=5,
            style_table={"overflowX":"auto"},
            style_cell=tbl_cell, style_header=tbl_head)),

        section("✅ Closed", dash_table.DataTable(
            id="tbl_closed",
            page_size=5,
            style_table={"overflowX":"auto"},
            style_cell=tbl_cell, style_header=tbl_head)),
    ], style={"display":"grid","gridTemplateColumns":"1fr 1fr","gap":"8px"}),

    html.Div([
        section("📊 Performance", html.Div(id="perf")),
        section("🧠 Lernfortschritt", html.Div(id="learn_perf")),
    ], style={"display":"grid","gridTemplateColumns":"1fr 1fr","gap":"8px"}),

    dcc.Interval(id="tick", interval=REFRESH_MS, n_intervals=0)
], style={"backgroundColor":BG, "minHeight":"100vh","padding":"14px","fontFamily":"-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Inter,Helvetica,Arial"})

@app.callback(
    [Output("status","children"),
     Output("btc_live","children"),
     Output("daycap_box","children"),
     Output("pnl_box","children"),
     Output("tbl_open","data"),   Output("tbl_open","columns"),
     Output("tbl_closed","data"), Output("tbl_closed","columns"),
     Output("perf","children"),
     Output("learn_perf","children")],
    Input("tick","n_intervals")
)
def refresh(_):
    snap = shared_state.snapshot()

    # --- Status ---
    ws = snap.get("ws_status", {})
    latency = snap.get("latency_ms", 0)
    status = f"Spot: {ws.get('spot','?')} | Futures: {ws.get('futures','?')} | Latenz: {latency} ms"

    # --- BTC live ---
    btc_price = None
    for (m, s), t in snap.get("ticks", {}).items():
        if s == "BTCUSDT":
            btc_price = t.get("price")
            break
    btc_text = f"{btc_price:,.2f}" if isinstance(btc_price, (int,float)) else "–"

    # --- Daycap ---
    dc = snap.get("accounts", {}).get("daycap", {"total":175.0,"used":0.0})
    used = float(dc.get("used", 0.0)); total = float(dc.get("total", 175.0))
    daycap_text = f"{used:.2f} / {total:.2f} USDT"

    # --- Trades (defensiv) ---
    open_cols   = ["symbol","side","entry_price","qty","leverage","timestamp"]
    closed_cols = ["symbol","side","entry_price","exit_price","qty","leverage","pnl","timestamp"]

    df_o = pd.DataFrame(snap.get("open_trades") or [], columns=open_cols)
    df_c = pd.DataFrame(snap.get("closed_trades") or [], columns=closed_cols)

    # nur die letzten 5 zeigen (Server-Logik capped schon, aber doppelt hält besser)
    if not df_o.empty: df_o = df_o.tail(5)
    if not df_c.empty: df_c = df_c.tail(5)

    cols_o = [{"name":c,"id":c} for c in df_o.columns]
    cols_c = [{"name":c,"id":c} for c in df_c.columns]

    # --- PnL & Performance ---
    pnl_val = float(df_c["pnl"].sum()) if not df_c.empty and "pnl" in df_c else 0.0
    pnl_color = POS if pnl_val >= 0 else NEG
    pnl_box = html.Span(f"{pnl_val:+.2f} USDT", style={"color": pnl_color, "fontWeight":"800"})

    perf_html = html.Div([
        html.Div(f"Trades geschlossen: {0 if df_c.empty else len(df_c)}", style={"color":TXT}),
        html.Div(f"Gesamt PnL: {pnl_val:+.2f} USDT", style={"color": pnl_color, "fontWeight":"700"})
    ])

    # --- Lernfortschritt ---
    learn = "Keine Daten"
    try:
        with open("data/curriculum_state.json","r",encoding="utf-8") as f:
            st = json.load(f)
        lvl = int(st.get("level", 0))
        rewards = st.get("recent_rewards", [])[-2:]  # nur 2 neueste
        learn = html.Div([
            html.Div(f"Level {lvl}", style={"color":ACC,"fontWeight":"900","fontSize":"20px"}),
            html.Div("Letzte Rewards: " + ", ".join([f"{r:+.2f}" for r in rewards]) if rewards else "–",
                     style={"color":POS if (rewards and rewards[-1] >= 0) else NEG}),
        ])
    except Exception:
        pass

    return (status, btc_text, daycap_text, pnl_box,
            df_o.to_dict("records"), cols_o,
            df_c.to_dict("records"), cols_c,
            perf_html, learn)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8050, debug=False)
