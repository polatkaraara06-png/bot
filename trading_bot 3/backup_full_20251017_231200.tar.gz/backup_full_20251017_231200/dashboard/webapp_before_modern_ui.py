
import os, threading, time, json
from flask import Flask
import dash
from dash import html, dcc, dash_table
from dash.dependencies import Input, Output
import pandas as pd
from core.shared_state import shared_state
from core.ws_client.spot_ws import run as run_spot
from core.ws_client.futures_ws import run as run_fut
from core.scanner import start_scanner_thread

def boot():
    with shared_state.lock:
        shared_state.accounts["daycap"]={"total":175.0,"used":0.0}
    shared_state.autoload()
    threading.Thread(target=run_spot,daemon=True).start()
    threading.Thread(target=run_fut,daemon=True).start()
    start_scanner_thread()

boot()
server=Flask(__name__)
app=dash.Dash(__name__,server=server)
REFRESH=1500

BG="#0c0c0c"; TXT="#00e6ff"; POS="#00ff99"; NEG="#ff4466"

CARD={"backgroundColor":"#111","padding":"8px","borderRadius":"6px","marginBottom":"8px"}

app.layout=html.Div([
    html.H2("🧠 CrazyBot Dashboard",style={"color":TXT,"textAlign":"center"}),
    html.Div(id="status",style={"color":TXT,"textAlign":"center"}),
    html.Div(id="btc_live",style={"fontSize":"24px","fontWeight":"bold","color":POS,"textAlign":"center"}),
    html.Div([
        html.H4("📊 Trades",style={"color":TXT}),
        dash_table.DataTable(id="tbl_open",page_size=5,style_table={"overflowX":"auto"},
            style_header={"backgroundColor":"#222","color":TXT},
            style_cell={"backgroundColor":"#111","color":"#EEE"}),
        html.H4("💰 Closed",style={"color":TXT}),
        dash_table.DataTable(id="tbl_closed",page_size=5,style_table={"overflowX":"auto"},
            style_header={"backgroundColor":"#222","color":TXT},
            style_cell={"backgroundColor":"#111","color":"#EEE"}),
        html.H4("📈 Performance",style={"color":TXT}),
        html.Div(id="perf",style={"fontSize":"16px","color":TXT})
    ],style={"maxWidth":"95%","margin":"auto"}),

    html.H4("🧩 Lernfortschritt",style={"color":TXT,"textAlign":"center"}),
    html.Div(id="learn_perf",style={"color":TXT,"textAlign":"center"}),

    dcc.Interval(id="tick",interval=REFRESH,n_intervals=0)
],style={"backgroundColor":BG,"padding":"15px","fontFamily":"Consolas"})

@app.callback(
 [Output("status","children"),Output("btc_live","children"),
  Output("tbl_open","data"),Output("tbl_open","columns"),
  Output("tbl_closed","data"),Output("tbl_closed","columns"),
  Output("perf","children"),Output("learn_perf","children")],
 [Input("tick","n_intervals")]
)
def refresh(_):
    snap=shared_state.snapshot()
    ws=snap["ws_status"]
    status=f"Spot: {ws.get('spot')} | Futures: {ws.get('futures')} | Latenz: {snap['latency_ms']} ms"
    btc=None
    for (m,s),t in snap["ticks"].items():
        if s=="BTCUSDT": btc=t.get("price"); break
    btc_text=f"BTC/USDT {btc:.2f}" if btc else "BTC – keine Daten"

    df_o=pd.DataFrame(snap["open_trades"][-5:]) if snap["open_trades"] else pd.DataFrame(columns=["symbol","side","qty","entry_price","leverage"])
    df_c=pd.DataFrame(snap["closed_trades"][-5:]) if snap["closed_trades"] else pd.DataFrame(columns=["symbol","side","entry_price","exit_price","pnl"])
    cols_o=[{"name":c,"id":c} for c in df_o.columns]; cols_c=[{"name":c,"id":c} for c in df_c.columns]
    pnl=df_c["pnl"].sum() if "pnl" in df_c else 0.0
    color=POS if pnl>=0 else NEG
    perf=html.Span(f"Gesamt PnL: {pnl:+.2f} USDT",style={"color":color,"fontWeight":"bold"})

    # Lernsystem
    learn_html="Keine Daten"
    path="data/curriculum_state.json"
    if os.path.exists(path):
        with open(path) as f: data=json.load(f)
        lvl=data.get("level",0); rw=data.get("recent_rewards",[])
        learn_html=html.Div([
            html.H5(f"Level {lvl}",style={"color":TXT}),
            html.Div("Letzte Rewards:",style={"marginTop":"4px"}),
            html.Div(", ".join([f"{r:+.2f}" for r in rw[-2:]]),style={"color":POS})
        ])
    return status,btc_text,df_o.to_dict("records"),cols_o,df_c.to_dict("records"),cols_c,perf,learn_html

if __name__=="__main__":
    app.run(debug=True,port=8050,host="0.0.0.0")
