import os, json
from flask import Flask
import dash
from dash import html, dcc, dash_table
from dash.dependencies import Input, Output
import pandas as pd
from core.shared_state import shared_state

# --- Server & App ---
server = Flask(__name__)
app = dash.Dash(__name__, server=server)
REFRESH = 1000

# --- Farben & Styles ---
BG = "#1a1a1a"
CARD = "#2b2b2b"
TEXT = "#e0e0e0"
ACCENT = "#00ffff"
POS = "#00ff88"
NEG = "#ff4477"

def card(title, content):
    return html.Div([
        html.H4(title, style={"color":ACCENT,"marginBottom":"5px"}),
        html.Div(content, style={"color":TEXT,"fontSize":"16px"})
    ], style={"backgroundColor":CARD,"padding":"10px","borderRadius":"8px","margin":"5px"})

app.layout = html.Div([
    html.H1("💫 CrazyBot Dashboard", style={"color":ACCENT,"textAlign":"center","marginBottom":"10px"}),

    html.Div([
        card("BTC/USDT", html.Div(id="btc_live")),
        card("Daycap", html.Div(id="daycap_box")),
        card("Total PnL", html.Div(id="pnl_box")),
    ], style={"display":"flex","justifyContent":"space-around"}),

    html.Div([
        card("🟢 Open Trades", dash_table.DataTable(id="open_tbl", page_size=5,
             style_table={"overflowX":"auto"},
             style_cell={"backgroundColor":CARD,"color":TEXT,"textAlign":"center"})),
        card("🔵 Closed Trades", dash_table.DataTable(id="closed_tbl", page_size=5,
             style_table={"overflowX":"auto"},
             style_cell={"backgroundColor":CARD,"color":TEXT,"textAlign":"center"}))
    ], style={"display":"flex","justifyContent":"space-around"}),

    html.Div([
        card("📊 Performance", html.Div(id="perf_box")),
        card("🧠 Lernfortschritt", html.Div(id="learn_box"))
    ], style={"display":"flex","justifyContent":"space-around","marginTop":"10px"}),

    dcc.Interval(id="tick", interval=REFRESH, n_intervals=0)
], style={"backgroundColor":BG,"padding":"15px","fontFamily":"Consolas","minHeight":"100vh"})

@app.callback(
    [Output("btc_live","children"),
     Output("daycap_box","children"),
     Output("pnl_box","children"),
     Output("open_tbl","data"), Output("open_tbl","columns"),
     Output("closed_tbl","data"), Output("closed_tbl","columns"),
     Output("perf_box","children"),
     Output("learn_box","children")],
    [Input("tick","n_intervals")]
)
def refresh(_):
    snap = shared_state.snapshot()

    # --- BTC ---
    btc_price = None
    for (m,s),t in snap["ticks"].items():
        if s == "BTCUSDT":
            btc_price = t.get("price")
            break
    btc_txt = f"{btc_price:,.2f}" if btc_price else "–"

    # --- Daycap ---
    dc = snap["accounts"].get("daycap", {"total":175,"used":0})
    used, total = float(dc.get("used",0)), float(dc.get("total",175))
    daycap_html = f"{used:.2f} / {total:.2f} USDT"

    # --- PnL ---
    df_c = pd.DataFrame(snap["closed_trades"])
    pnl = df_c["pnl"].sum() if not df_c.empty else 0.0
    pnl_color = POS if pnl >= 0 else NEG
    pnl_txt = html.Span(f"{pnl:+.2f} USDT", style={"color":pnl_color,"fontWeight":"bold"})

    # --- Trades ---
    df_o = pd.DataFrame(snap["open_trades"]) if snap["open_trades"] else pd.DataFrame(columns=["symbol","side","qty","entry_price","leverage"])
    cols_o = [{"name":c,"id":c} for c in df_o.columns]
    df_c = pd.DataFrame(snap["closed_trades"]) if snap["closed_trades"] else pd.DataFrame(columns=["symbol","side","entry_price","exit_price","pnl"])
    cols_c = [{"name":c,"id":c} for c in df_c.columns]

    # --- Performance ---
    perf_html = html.Div([
        html.Div(f"Gesamt PnL: {pnl:+.2f} USDT", style={"color":pnl_color}),
        html.Div(f"Anzahl Trades: {len(df_c)}", style={"color":TEXT})
    ])

    # --- Lernfortschritt ---
    learn_html = "Keine Daten"
    try:
        with open("data/curriculum_state.json","r") as f:
            data = json.load(f)
        lvl = data.get("level", 0)
        rewards = data.get("recent_rewards", [])
        learn_html = html.Div([
            html.Div(f"Level: {lvl}", style={"color":ACCENT,"fontWeight":"bold","fontSize":"18px"}),
            html.Div(f"Letzte Rewards: {', '.join([f'{r:+.2f}' for r in rewards])}", style={"color":POS})
        ])
    except Exception:
        pass

    return (btc_txt, daycap_html, pnl_txt,
            df_o.to_dict("records"), cols_o,
            df_c.to_dict("records"), cols_c,
            perf_html, learn_html)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8050, debug=False)
