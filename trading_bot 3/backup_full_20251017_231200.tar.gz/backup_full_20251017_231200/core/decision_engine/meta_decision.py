# Hook für learning_monitor-Interventionen (vorerst immer OK)
def permitted()->bool:
    return True
