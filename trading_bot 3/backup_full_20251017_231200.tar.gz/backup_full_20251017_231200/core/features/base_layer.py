class FeatureLayer:
    name = "base"
    def compute(self, market:str, symbol:str, tf:int, shared_state)->dict:
        return {}
