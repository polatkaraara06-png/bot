import os, json, time, socket, threading
from websocket import WebSocketApp
from dotenv import load_dotenv
from ..shared_state import shared_state
load_dotenv()

# ---- IPv4 erzwingen ----
def force_ipv4():
    orig = socket.getaddrinfo
    def only4(*a, **k): return [r for r in orig(*a, **k) if r[0]==socket.AF_INET]
    socket.getaddrinfo = only4
if os.getenv("USE_IPV4","True")=="True": force_ipv4()
# ------------------------

WSS_URL = os.getenv("WSS_URL_FUTURES", "wss://stream.bybit.com/v5/public/linear")
SYMBOLS = [s.strip() for s in os.getenv("SYMBOLS", "BTCUSDT,ETHUSDT,SOLUSDT").split(",")]

def _on_message(ws, msg):
    try:
        data = json.loads(msg)
        if "topic" not in data or not data["topic"].endswith("tickers"):
            return
        items = data.get("data", [])
        if not isinstance(items, list):
            items = [items]
        now = time.time()
        for it in items:
            sym = it.get("symbol")
            last_price = it.get("lastPrice") or it.get("price")
            if not sym or not last_price:
                continue
            lp = float(last_price)
            with shared_state.lock:
                shared_state.ticks[("futures", sym)] = {"price": lp, "ts": now}
                shared_state.ws_status["futures"] = "connected"
    except Exception as e:
        with shared_state.lock:
            shared_state.ws_status["futures"] = f"error:{e}"

def _on_open(ws):
    subs = [f"tickers.{s}" for s in SYMBOLS]
    ws.send(json.dumps({"op": "subscribe", "args": subs}))
    with shared_state.lock:
        shared_state.ws_status["futures"] = "subscribed"
    print(f"[WSS-Futures] Subscribed to {', '.join(SYMBOLS)}")

def _on_close(ws, *args):
    with shared_state.lock:
        shared_state.ws_status["futures"] = "disconnected"
    print("[WSS-Futures] Connection closed. Reconnecting...")

# ============================================================
# AUTO-SUBSCRIBE – dynamische Hot-Coins für Futures
# ============================================================
def _auto_subscribe_thread(ws_send_func, interval=15):
    known = set()
    while True:
        try:
            with shared_state.lock:
                subs = shared_state.accounts.get("hot_coins", [])
            new_syms = [s for s in subs if s not in known]
            for sym in new_syms:
                msg = {"op": "subscribe", "args": [f"tickers.{sym}"]}
                ws_send_func(msg)
                known.add(sym)
                print(f"[AutoSub-FUTURES] subscribed -> {sym}")
        except Exception as e:
            print(f"[AutoSub-FUTURES] Error: {e}")
        time.sleep(interval)

def start_auto_subscribe(ws_send_func):
    threading.Thread(target=_auto_subscribe_thread,
                     args=(ws_send_func,), daemon=True).start()

# ============================================================
# Haupt-Lauf des Futures-WS-Clients
# ============================================================
def _run_ws():
    while True:
        try:
            ws = WebSocketApp(
                WSS_URL,
                on_open=_on_open,
                on_message=_on_message,
                on_close=_on_close
            )

            # 🟢 Aktivieren des Auto-Subscribe-Threads
            start_auto_subscribe(lambda msg: ws.send(json.dumps(msg)))

            ws.run_forever(ping_interval=20, ping_timeout=10)
        except Exception as e:
            with shared_state.lock:
                shared_state.ws_status["futures"] = f"error:{e}"
            time.sleep(5)

def run():
    threading.Thread(target=_run_ws, daemon=True).start()
