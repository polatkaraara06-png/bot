
import os, importlib, threading, time, webbrowser, shutil

# ------- kleine Hilfsfunktion: Pycache leeren -------
def _purge_pycache():
    for root, dirs, files in os.walk("."):
        if "__pycache__" in dirs:
            try:
                shutil.rmtree(os.path.join(root, "__pycache__"), ignore_errors=True)
            except Exception:
                pass

print("=== ⚙️ CrazyBot Autostart (clean) ===")
_purge_pycache()
print("🧹 Cache gelöscht.\n")

# ------- Imports (hart & eindeutig) -------
from core.shared_state import shared_state
from core.ws_client.spot_ws import run as run_spot_ws
from core.ws_client.futures_ws import run as run_futures_ws
from core.scanner import start_scanner_thread, start_auto_trade
from core.ai import online_rl
from core.ai.learning_module import RLAgent

# ------- Boot-Sequenz -------
def boot_all():
    # Daycap-Reset (Testphase)
    with shared_state.lock:
        dc = shared_state.accounts.setdefault("daycap", {"total": 175.0, "used": 0.0})
        dc["total"] = float(dc.get("total", 175.0))
        dc["used"]  = 0.0
    print("[BOOT] Daycap zurückgesetzt (used=0.0)")

    # Websocket-Feeds
    threading.Thread(target=run_spot_ws,     daemon=True, name="SpotWS").start()
    threading.Thread(target=run_futures_ws,  daemon=True, name="FuturesWS").start()
    print("[BOOT] Websocket-Feeds gestartet")

    # Scanner & Auto-Trader
    start_scanner_thread()
    start_auto_trade()
    print("[BOOT] Scanner & Auto-Trader gestartet")

    # Lernsystem (persistenter Agent)
    online_rl.agent = RLAgent.load()
    threading.Thread(target=online_rl.start_online_rl_thread, daemon=True, name="RLTrainer").start()
    perf = getattr(online_rl.agent, "performance", 0.0)
    print(f"[BOOT] RLAgent aktiv (Level={online_rl.agent.level}, Perf={perf:+.2f})")

if __name__ == "__main__":
    # Modul-Sanity-Check (nur Infoausgabe)
    modules = ("core.shared_state","core.paper_trader","core.ai.online_rl","dashboard.webapp")
    for mod in modules:
        try:
            m = importlib.import_module(mod)
            print(f"✅ Modul geladen: {mod} → {os.path.abspath(m.__file__)}")
        except Exception as e:
            print(f"❌ Fehler beim Laden von {mod}: {e}")

    # Systeme starten
    boot_all()

    # Dashboard starten
    from dashboard import webapp
    url = "http://127.0.0.1:8050/"
    try:
        threading.Thread(target=lambda: (time.sleep(2), webbrowser.open(url)), daemon=True).start()
    except Exception as e:
        print(f"[BOOT] Browser-Open fehlgeschlagen: {e}")
    print(f"[DASHBOARD] Starte unter {url}")
    webapp.app.run(host="0.0.0.0", port=8050, debug=False, use_reloader=False)
